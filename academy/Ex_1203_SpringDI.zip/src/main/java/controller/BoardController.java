package controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import service.BoardService;

@Controller	// 어노테이션을 해야 controller로 인식한다
public class BoardController {	// 반드시 controller가  controller 패키지에 들어있을 필요가 없다
	//Controller : jsp의 Servlet역할
	
	/*
	 * @ : 어노테이션(프로그래밍 주석)
	 	* @Override처럼 컴파일러에게 오버라이딩 메서드임을 빠르게 캐치시키는 용도로 쓰이기도 한다
	 	* 현재 클래스를 어노테이션을 통해 특수한 기능으로 동작하도록 인식시키기 위한 방법 
	*/
	
	//Controller는 root-context.xml에서 객체화 시키지 않는 유일한 클래스
	
	BoardService service; // BoardService가 있어야 select()를 호출할 수 있다
	
	public BoardController() {
		System.out.println("---BoardController()의 생성자가 호출됨---");
	}
	
	public void setService(BoardService service) {	// Setter Injection을 사용하기 위해서
		System.out.println("---setService() 호출됨---");
		this.service = service;
	}
	
	// servlet의 단점 : servlet당 하나의 forwarding만 가능하다
	// controller의 장점 : 하나만 있어도 여러개의 mapping을 보낼 수 있다
	@RequestMapping("/list.do") // list.do 호출
	public String list(Model model) { // Model 인터페이스 : Servlet과 Controller간의 중간 매개체(binding 역할)
		//list.do를 url로 요청 받았을 때 호출되는 메서드
		List list = service.selectList();
		//model을 통해 list를 binding
		model.addAttribute("list",list);
		

		return "board_list"; // forwarding
	}

}
