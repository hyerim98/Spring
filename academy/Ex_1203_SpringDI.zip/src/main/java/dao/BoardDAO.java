package dao;

import java.util.List;

public interface BoardDAO {	// 실제 DAO class를 만들었을 때 쓸 거 같은 것을 만들어 놓는다 
	int insert(Object ob);
	List selectList();
	int update(Object ob);
	int delete(int idx);
}
