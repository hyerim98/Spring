package dao;

import java.util.ArrayList;
import java.util.List;

public class BoardDAOImpl implements BoardDAO {

	@Override
	public int insert(Object ob) {
		
		return 0;
	}

	@Override
	public List selectList() {
		List<String> list = new ArrayList<String>(); // mapper들어갔다 나왔다고 가정
		list.add("사과");
		list.add("귤");
		list.add("청포도");
		list.add("복숭아");
		return list;
	}

	@Override
	public int update(Object ob) {
		
		return 0;
	}

	@Override
	public int delete(int idx) {
		
		return 0;
	}

}
