package service;

import java.util.List;

public interface BoardService {
	List selectList();
}
