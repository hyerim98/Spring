package service;

import java.util.List;

import dao.BoardDAO;

public class BoardServiceImpl implements BoardService{
	
	BoardDAO dao;
	//DeptDAO dept; : 새로 추가할 때 마다 DAO 추가시킨다
	
	public BoardServiceImpl(BoardDAO dao) {
		this.dao = dao;
	}

	@Override
	public List selectList() {
		
		return dao.selectList();
	}

}
