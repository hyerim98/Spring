package common;

public class Common { // 각 게시판 별 한 페이지에 보여질 게시글의 개수 변경을 편리하게 하기 위한 클래스
	
	//현재 게시판
	public static class Board{
		
		public static final String VIEW_PATH = "/WEB-INF/views/board/";
		
		public final static int BLOCKLIST = 5;	// 한 페이지에 보여 줄 게시글의 수
		
		//< 1 2 3 4 5> -> < 6 7 >
		public final static int BLOCKPAGE = 3;	//현재 페이지에 보여 줄 최대 페이지 메뉴 수
	}
	
	
	//공지사항 게시판
	public static class Notice{
		public final static int BLOCKLIST = 5;
	}

}
