package ex;

import java.util.List;

public class MyList {
	List list;

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
	

}
