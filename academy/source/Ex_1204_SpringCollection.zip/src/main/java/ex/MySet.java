package ex;

import java.util.Set;

public class MySet {
	Set set;

	public Set getSet() {
		return set;
	}

	public void setSet(Set set) {
		this.set = set;
	}
	
	
}
