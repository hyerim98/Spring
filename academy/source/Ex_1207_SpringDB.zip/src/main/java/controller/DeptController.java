package controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import dao.DeptDAO;
import vo.DeptVO;

@Controller
public class DeptController {  // jsp의 servlet역할
	public static final String VIEW_PATH = "/WEB-INF/views/dept/";
	DeptDAO dao;

	public DeptController(DeptDAO dao) {
		this.dao = dao;
	}
	
	// mapping을 여러개 잡을 수 있다(단, mapping이 중복되면 안된다)
	@RequestMapping(value={"/","/dept_list.do"}) // "/" : 첫 페이지(여러개의 mapping중에서 1곳에서만 사용가능)
	public String list(Model model) {
		//dao로 부터 부서 목록을 요청
		List<DeptVO> list = dao.selectList();
		
		//model을 통해 list를 바인딩
		model.addAttribute("list",list);
		
		//포워딩
		return VIEW_PATH + "dept_list.jsp";
	}
	
}
