package controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import dao.GogekDAO;
import vo.GogekVO;

@Controller
public class GogekController {
	GogekDAO gdao;
	public static final String VIEW_PATH = "/WEB-INF/views/gogek/";
	
	public GogekController(GogekDAO gdao) {
		this.gdao = gdao;
	}
	
	@RequestMapping("/gogek_list.do")
	public String gogek_list(Model model) {
		List<GogekVO> list = gdao.glist();
		model.addAttribute("list",list);
		return VIEW_PATH + "gogek_list.jsp";
	}
}
