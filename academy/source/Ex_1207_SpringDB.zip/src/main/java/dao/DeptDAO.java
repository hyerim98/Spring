package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.DeptVO;

public class DeptDAO {
	SqlSession sqlsession;

	public DeptDAO(SqlSession sqlsession) {
		this.sqlsession = sqlsession;
	}
	
	//부서정보 조회
	public List<DeptVO> selectList(){
		List<DeptVO> list = sqlsession.selectList("dept.dept_list"); // mapper 사용
		//자동으로 close가 된다
		return list;
	}
}
