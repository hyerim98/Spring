package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.GogekVO;

public class GogekDAO {
	SqlSession sqlsession;
	
	public void setSqlsession(SqlSession sqlsession) {
		this.sqlsession = sqlsession;
	}
	
	public List<GogekVO> glist(){
		List<GogekVO> list = sqlsession.selectList("gogek.gogek_list");
		return list;
	}
}
