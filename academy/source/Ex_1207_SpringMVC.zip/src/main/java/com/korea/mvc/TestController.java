package com.korea.mvc;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {
	/* 부모 자식 관계
	 * @Component
	 	* @Controller
	 		* @Service
	 			* @Repository 
	*/
	
	public static final String VIEW_PATH = "/WEB-INF/views/test/";
	
	public TestController() {
		System.out.println("---TestController의 생성자---");
	}
	
	@RequestMapping("/test.do") // test.do를 호출하면 내 바로 밑에 있는 메서드가 호출됨
	public String test(Model model, HttpServletRequest request) { //HttpServletRequest : ip를 구하기 위한 파라미터
		String[] msg = {"사과","배","포도","오렌지","바나나"};
		model.addAttribute("msg",msg);	// binding
		
		String ip = request.getRemoteAddr();
		request.setAttribute("ip", ip);
		
		// 요청을 sevlet-context.xml이 아닌 여기서 한다 ( 폴더를 나누기 위해 )
		return VIEW_PATH + "test.jsp"; // forwarding
	}
	
	@RequestMapping("/test2.do")
	public ModelAndView test2(HttpServletRequest request) { // 기본적으로 사용하지 않는다
		//data와  view정보를 하나로 포장해서 전달하기 위한 클래스
		ModelAndView mv = new ModelAndView();
		String ip = request.getRemoteAddr();
		String[] msg = {"홍길동","박길동","김길동"};
		
		//ModelAndView의 binding(mv에 data를 담는다)
		mv.addObject("ip",ip);
		mv.addObject("msg",msg);
		//ModelAndView의 forwarding
		mv.setViewName(VIEW_PATH+"test.jsp");
		
		return mv;
	}

}
