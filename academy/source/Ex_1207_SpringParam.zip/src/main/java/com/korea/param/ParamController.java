package com.korea.param;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import vo.PersonVO;

@Controller
public class ParamController {
	public static final String VIEW_PATH = "/WEB-INF/views/person/";
	
	@RequestMapping("/insert_form.do")
	public String insert_form(Model model) {
		
		
		
		return VIEW_PATH+"insert_form.jsp";
	}
	
	
	//insert_form.jsp에서 넘어 온 파라미터를 받는 곳 
	@RequestMapping("/insert1.do")
	public String insert1(Model model, String name, int age, String tel) { // 넘어 온 파라미터 순서대로,이름이 같아야 받아짐
		//insert1.do?name=김태국&age=20&tel=010-1111-1111
		
		//name,age,tel이 insert1()메서드의 파라미터로 자동으로 넘어온다
		//int형식은 형 변환까지 자동으로 처리
		PersonVO vo = new PersonVO();
		vo.setName(name);
		vo.setAge(age);
		vo.setTel(tel);
		
		model.addAttribute("vo",vo);
		
		return VIEW_PATH+"insert_result.jsp";
		
	}
	
	@RequestMapping("/insert2.do")
	public String insert2(Model model, PersonVO vo) { // vo로 파라미터가 통째로 받아짐(알아서 setter작업을 해줌)
													  // 파라미터로 vo변수들을 다 넘기지 못해도 받은 것까지 알아서 저장해준다
		//insert1.do?name=김태국&age=20&tel=010-1111-1111
		
		//파라미터로 넘어 온 값을 vo에 속성이 일치하는 변수에 자동으로 추가해 준다
		model.addAttribute("vo",vo);
		
		return VIEW_PATH+"insert_result.jsp";
		
	}
}
