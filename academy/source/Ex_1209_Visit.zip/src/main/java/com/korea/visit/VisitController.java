package com.korea.visit;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import common.MyCommon;
import dao.VisitDAO;
import vo.VisitVO;

@Controller
public class VisitController {
	VisitDAO dao;
	
	
	public VisitController(VisitDAO dao) {
		this.dao = dao;
	}
	
	@RequestMapping(value= {"/","/visit_list.do"})
	public String list(Model model) {
		List<VisitVO> list = dao.selectList();
		model.addAttribute("list",list);
		return MyCommon.Visit.VIEW_PATH+"visit_list.jsp";
	}
	
	//새 글 쓰기 폼으로 이동
	@RequestMapping("/insert_form.do")
	public String insert_form(Model model) {
		return MyCommon.Visit.VIEW_PATH+"visit_insert_form.jsp";
	}
	
	//새 글 작성
	@RequestMapping("/insert.do")
	public String insert(Model model,VisitVO vo,HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		vo.setIp(ip);
		
		//vo를 통해 DB에 데이터를 추가
		dao.insert(vo);
		model.addAttribute("vo",vo);
		
		//jsp와 같은 view가 아닌 url매핑을 호출하고 싶은 경우
		return "redirect:visit_list.do"; // jsp의 response.sendRedirct("visit_list.do");와 같다고 보면 된다
	}
	
	//방명록 수정을 위한 폼으로 이동
	@RequestMapping("/selectOne.do")
	public String selectOne(Model model,int idx) {
		VisitVO vo = dao.selectOne(idx);
		if(vo!=null) {
			model.addAttribute("vo",vo);
		}
		return MyCommon.Visit.VIEW_PATH+"visit_update.jsp";
	}
	
	/*@RequestMapping("/modify_form.do")
	public String selectOne(Model model,int idx) {
		VisitVO vo = dao.selectOne(idx);
		model.addAttribute("vo",vo);
		return MyCommon.Visit.VIEW_PATH+"visit_update.jsp";
	}*/
	
	@RequestMapping("/update.do")
	@ResponseBody // return값을 jsp등의 view로 인식하지 않고 Ajax의 콜백 메서드로 돌려주기 위한 어노테이션
	public String update(Model model,HttpServletRequest request,VisitVO vo) {
		//visit_update.jsp에서 넘겨준 idx,name,content,pwd를 파라미터 vo가 한번에 받는다
		vo.setIp(request.getRemoteAddr());
		int res = dao.update(vo);
		String result = "no";
		if(res>0) {
			result = "yes";
			model.addAttribute("vo",vo);
		}
		return result;
		//return "redirect:visit_list.do";
	}
	
	//게시물 삭제
	@RequestMapping("/delete.do")
	//Ajax 사용 시 반드시 추가시켜야 한다
	@ResponseBody // return값을 jsp등의 view로 인식하지 않고 Ajax의 콜백 메서드로 돌려주기 위한 어노테이션
	public String delete(Model model,int idx) {
		//delete.do?idx=2
		int res = dao.delete(idx);
		
		String result = "no";
		String resultStr = "";
		
		//삭제 성공
		if(res>0) {
			result="yes";
		}
		
		resultStr = String.format("[{'res':'%s'}]", result);
		
		//return "[{'res':'%s'}]";
		return resultStr; // 콜백메서드로 resultStr을 가지고 간다
		
		// 이렇게 호출하면 콜백메서드로 가지 않는다
		//return MyCommon.Visit.VIEW_PATH+"visit_list.jsp";
	}
}
