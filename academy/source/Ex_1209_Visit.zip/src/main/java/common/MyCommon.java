package common;

public class MyCommon {
	// visit경로
	public static class Visit{
		public static final String VIEW_PATH = "/WEB-INF/views/visit/";
	}
	
	//EX.dept 폴더 경로 생성하기
	public static class Dept{
		public static final String VIEW_PATH = "/WEB-INF/views/dept/";
	}
}
