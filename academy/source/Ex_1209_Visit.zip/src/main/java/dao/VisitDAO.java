package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.VisitVO;

public class VisitDAO {
	SqlSession sqlsession;

	public VisitDAO(SqlSession sqlsession) {
		this.sqlsession = sqlsession;
	}
	
	//방명록 조회
	public List<VisitVO> selectList(){
		List<VisitVO> list = sqlsession.selectList("v.visit_list");
		return list;
	}
	
	//새 글 추가
	public int insert(VisitVO vo) {
		int res = sqlsession.insert("v.visit_insert", vo);
		return res;
	}
	
	//게시글 수정을 위한 데이터 한 건 조회
	public VisitVO selectOne(int idx) {
		VisitVO vo = sqlsession.selectOne("v.visit_selectOne",idx);
		return vo;
	}
	
	//게시글 업데이트
	public int update(VisitVO vo) {
		int res = sqlsession.update("v.visit_update", vo);
		return res;
	}
	
	//글 삭제
	public int delete(int idx) {
		int res = sqlsession.delete("v.visit_delete", idx);
		return res;
	}
	
	
}
