package vo;

import org.springframework.web.multipart.MultipartFile;

public class PhotoVO {
	
	//각 input의 name속성인 title과 photo라는 이름으로 변수 지정해줘야 한다
	private String title; //제목
	
	//파일을 받아서 저장하기 위한 클래스
	MultipartFile photo;
	
	private String filename; // 업로드가 완료된 파일의 이름
	

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public MultipartFile getPhoto() {
		return photo;
	}

	public void setPhoto(MultipartFile photo) {
		this.photo = photo;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	
}


