package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import dao.DeptDAO;
import vo.DeptVO;

/*
 * @Repository, @Controller, @Service객체를 Component라고 한다 -> Auto-Detecting(자동생성)이 가능
*/

@Controller
public class TestController {
	@Autowired // -> new하면서 자동으로 만들어진다
	DeptDAO dept_dao; // DeptDAO class의 @Repository("dept_dao") 별칭 이름과 반드시 일치시켜야한다
	
	public TestController() {
		System.out.println("---TestController 생성자---");
	}
	
	@RequestMapping(value= {"/","/list.do"})
	public String dept_list(Model model) {
		List<DeptVO> dept_list = dept_dao.selectList();
		model.addAttribute("list",dept_list);
		return "total_list";
	}
}
