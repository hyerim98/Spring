package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.DeptVO;

//외부에서 현재 DAO를 식별할 수 있도록 별칭을 지정해준다 -> dept_dao
@Repository("dept_dao") // 데이터 관리 객체로써 해당 어노테이션이 명시되어 있어야 자동생성이 가능-> Bean객체 만들 필요없음
public class DeptDAO {
	
	/*
	 * 현재 DeptDAO는 servlet-context에서 auto-detecting을 통해 자동완성 되고 있다
	       이는 setter&constructor Injection을 사용할 수 없다
	       그러므로 sqlsession이 필요하다면 Autowired기능을 사용해야 한다
	*/
	@Autowired // sqlsession을 bean객체를 생성하지 않으니 sqlsession를 자동으로 객체화하는 작업
	SqlSession sqlsession;
	
	public DeptDAO() {
		System.out.println("-------DeptDAO 생성자-------");
	}
	
	public List<DeptVO> selectList(){
		List<DeptVO> list = sqlsession.selectList("dept.dept_list");
		return list;
	}
}
